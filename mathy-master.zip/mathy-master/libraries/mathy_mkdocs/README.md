## Mathy MkDocs Plugin

This plugin supports rendering mathy specific elements in a mkdocs page by template substitution.
