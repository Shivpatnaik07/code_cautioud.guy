from .plugin import MathyMkDocsPlugin  # noqa
