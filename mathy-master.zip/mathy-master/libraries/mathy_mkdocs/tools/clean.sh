#!/bin/bash
set -e
rm -rf .env/
rm -rf mathy_mkdocs.egg-info/
