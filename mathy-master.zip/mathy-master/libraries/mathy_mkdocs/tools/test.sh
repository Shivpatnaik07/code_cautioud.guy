#!/bin/bash
set -e
echo "Activating virtualenv... (if this fails you may need to run setup.sh first)"
. ../../.env/bin/activate
echo "TODO: add tests for mathy_mkdocs plugin"
# echo "Running tests..."
# pytest --cov=mathy
