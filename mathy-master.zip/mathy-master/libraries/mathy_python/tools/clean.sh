#!/bin/bash
set -e
rm -rf .env/
rm -rf .pytest_cache/
rm -rf .mypy_cache/
rm -rf build/
rm -rf dist/
rm -rf mathy.egg-info/
