def test_cas_overview_evaluate_expression_variables():
    from ...docs.snippets.cas.overview import evaluate_expression_variables  # noqa


def test_cas_overview_rules_factor_out():
    from ...docs.snippets.cas.overview import rules_factor_out  # noqa


def test_cas_overview_evaluate_expression():
    from ...docs.snippets.cas.overview import evaluate_expression  # noqa
