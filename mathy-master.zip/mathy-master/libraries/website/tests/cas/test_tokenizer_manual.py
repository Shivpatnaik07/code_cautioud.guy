def test_tokenizer_manual():
    from ...docs.snippets.cas import tokenizer_manual  # noqa
