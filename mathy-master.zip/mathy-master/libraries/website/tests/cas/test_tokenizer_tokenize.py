def test_tokenizer_tokenize():
    from ...docs.snippets.cas import tokenizer_tokenize  # noqa
