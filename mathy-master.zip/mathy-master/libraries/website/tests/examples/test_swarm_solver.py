def test_swarm_random_task():
    from ...docs.snippets.examples import swarm_random_task  # noqa


def test_swarm_generate_data():
    from ...docs.snippets.examples import swarm_data_generation  # noqa
