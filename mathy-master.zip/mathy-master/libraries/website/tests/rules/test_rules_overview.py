def test_rules_overview_custom_problem_text():
    from ...docs.snippets.rules import commutative_swap  # noqa
