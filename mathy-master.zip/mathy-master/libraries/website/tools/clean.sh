#!/bin/bash
set -e
rm -rf .env/
rm -rf .pytest_cache/
