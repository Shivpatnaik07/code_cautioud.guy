#!/bin/bash
set -e

. ../../.env/bin/activate

echo "API Docs disabled by Justin"
# python -m tools.docs
