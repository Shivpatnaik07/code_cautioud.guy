#!/bin/bash
echo "Building Netlify site..."
mkdocs build
