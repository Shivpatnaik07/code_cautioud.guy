echo "Converting all snippets to ipynb files:"

.env/bin/python tools/write_ipynb.py


 