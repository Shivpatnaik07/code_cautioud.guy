(cd libraries/website && sh tools/setup.sh && sh tools/develop.sh)
